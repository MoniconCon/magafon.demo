﻿namespace MarATHON
{
    partial class Inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.charityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet10 = new MarATHON.g464_GolubtsovDataSet10();
            this.charityTableAdapter = new MarATHON.g464_GolubtsovDataSet10TableAdapters.CharityTableAdapter();
            this.label14 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.raceKitOptionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expr1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMERABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet11 = new MarATHON.g464_GolubtsovDataSet11();
            this.nOMER_ATableAdapter = new MarATHON.g464_GolubtsovDataSet11TableAdapters.NOMER_ATableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.expr1DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet12 = new MarATHON.g464_GolubtsovDataSet12();
            this.sumTableAdapter = new MarATHON.g464_GolubtsovDataSet12TableAdapters.sumTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.aDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.neobhodimoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nEOLBHODIMOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet15 = new MarATHON.g464_GolubtsovDataSet15();
            this.nEOLBHODIMOTableAdapter = new MarATHON.g464_GolubtsovDataSet15TableAdapters.NEOLBHODIMOTableAdapter();
            this.g464_GolubtsovDataSet23 = new MarATHON.g464_GolubtsovDataSet23();
            this.nOMERABindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.nOMER_ATableAdapter1 = new MarATHON.g464_GolubtsovDataSet23TableAdapters.NOMER_ATableAdapter();
            this.g464_GolubtsovDataSet24 = new MarATHON.g464_GolubtsovDataSet24();
            this.sumBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sumTableAdapter1 = new MarATHON.g464_GolubtsovDataSet24TableAdapters.sumTableAdapter();
            this.g464_GolubtsovDataSet25 = new MarATHON.g464_GolubtsovDataSet25();
            this.nEOLBHODIMOBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.nEOLBHODIMOTableAdapter1 = new MarATHON.g464_GolubtsovDataSet25TableAdapters.NEOLBHODIMOTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.charityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nOMERABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nEOLBHODIMOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nOMERABindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nEOLBHODIMOBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(216, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Инвентарь";
            // 
            // charityBindingSource
            // 
            this.charityBindingSource.DataMember = "Charity";
            this.charityBindingSource.DataSource = this.g464_GolubtsovDataSet10;
            // 
            // g464_GolubtsovDataSet10
            // 
            this.g464_GolubtsovDataSet10.DataSetName = "g464_GolubtsovDataSet10";
            this.g464_GolubtsovDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // charityTableAdapter
            // 
            this.charityTableAdapter.ClearBeforeFill = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(224, 238);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Состав комплекта";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(144, 45);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(166, 13);
            this.label51.TabIndex = 51;
            this.label51.Text = "Всего зарегалось на марафон:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(316, 45);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(41, 13);
            this.label52.TabIndex = 52;
            this.label52.Text = "label52";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 53;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonShadow;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.raceKitOptionIdDataGridViewTextBoxColumn,
            this.expr1DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.nOMERABindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(123, 75);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(212, 147);
            this.dataGridView1.TabIndex = 54;
            // 
            // raceKitOptionIdDataGridViewTextBoxColumn
            // 
            this.raceKitOptionIdDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.raceKitOptionIdDataGridViewTextBoxColumn.DataPropertyName = "RaceKitOptionId";
            this.raceKitOptionIdDataGridViewTextBoxColumn.HeaderText = "Комплект";
            this.raceKitOptionIdDataGridViewTextBoxColumn.Name = "raceKitOptionIdDataGridViewTextBoxColumn";
            this.raceKitOptionIdDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.raceKitOptionIdDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.raceKitOptionIdDataGridViewTextBoxColumn.Width = 63;
            // 
            // expr1DataGridViewTextBoxColumn
            // 
            this.expr1DataGridViewTextBoxColumn.DataPropertyName = "Expr1";
            this.expr1DataGridViewTextBoxColumn.HeaderText = "Выбрало данный вариант";
            this.expr1DataGridViewTextBoxColumn.Name = "expr1DataGridViewTextBoxColumn";
            // 
            // nOMERABindingSource
            // 
            this.nOMERABindingSource.DataMember = "NOMER_A";
            this.nOMERABindingSource.DataSource = this.g464_GolubtsovDataSet11;
            // 
            // g464_GolubtsovDataSet11
            // 
            this.g464_GolubtsovDataSet11.DataSetName = "g464_GolubtsovDataSet11";
            this.g464_GolubtsovDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nOMER_ATableAdapter
            // 
            this.nOMER_ATableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.expr1DataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.sumBindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(332, 75);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(149, 148);
            this.dataGridView2.TabIndex = 55;
            // 
            // expr1DataGridViewTextBoxColumn1
            // 
            this.expr1DataGridViewTextBoxColumn1.DataPropertyName = "Expr1";
            this.expr1DataGridViewTextBoxColumn1.HeaderText = "Необходимо";
            this.expr1DataGridViewTextBoxColumn1.Name = "expr1DataGridViewTextBoxColumn1";
            // 
            // sumBindingSource
            // 
            this.sumBindingSource.DataMember = "sum";
            this.sumBindingSource.DataSource = this.g464_GolubtsovDataSet12;
            // 
            // g464_GolubtsovDataSet12
            // 
            this.g464_GolubtsovDataSet12.DataSetName = "g464_GolubtsovDataSet12";
            this.g464_GolubtsovDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sumTableAdapter
            // 
            this.sumTableAdapter.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(533, 431);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 56;
            this.button2.Text = "Далее";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.aDataGridViewTextBoxColumn,
            this.bDataGridViewTextBoxColumn,
            this.cDataGridViewTextBoxColumn,
            this.neobhodimoDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.nEOLBHODIMOBindingSource1;
            this.dataGridView3.Location = new System.Drawing.Point(46, 254);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(445, 200);
            this.dataGridView3.TabIndex = 57;
            // 
            // aDataGridViewTextBoxColumn
            // 
            this.aDataGridViewTextBoxColumn.DataPropertyName = "A";
            this.aDataGridViewTextBoxColumn.HeaderText = "A";
            this.aDataGridViewTextBoxColumn.Name = "aDataGridViewTextBoxColumn";
            // 
            // bDataGridViewTextBoxColumn
            // 
            this.bDataGridViewTextBoxColumn.DataPropertyName = "B";
            this.bDataGridViewTextBoxColumn.HeaderText = "B";
            this.bDataGridViewTextBoxColumn.Name = "bDataGridViewTextBoxColumn";
            // 
            // cDataGridViewTextBoxColumn
            // 
            this.cDataGridViewTextBoxColumn.DataPropertyName = "C";
            this.cDataGridViewTextBoxColumn.HeaderText = "C";
            this.cDataGridViewTextBoxColumn.Name = "cDataGridViewTextBoxColumn";
            // 
            // neobhodimoDataGridViewTextBoxColumn
            // 
            this.neobhodimoDataGridViewTextBoxColumn.DataPropertyName = "Neobhodimo";
            this.neobhodimoDataGridViewTextBoxColumn.HeaderText = "Neobhodimo";
            this.neobhodimoDataGridViewTextBoxColumn.Name = "neobhodimoDataGridViewTextBoxColumn";
            this.neobhodimoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nEOLBHODIMOBindingSource
            // 
            this.nEOLBHODIMOBindingSource.DataMember = "NEOLBHODIMO";
            this.nEOLBHODIMOBindingSource.DataSource = this.g464_GolubtsovDataSet15;
            // 
            // g464_GolubtsovDataSet15
            // 
            this.g464_GolubtsovDataSet15.DataSetName = "g464_GolubtsovDataSet15";
            this.g464_GolubtsovDataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nEOLBHODIMOTableAdapter
            // 
            this.nEOLBHODIMOTableAdapter.ClearBeforeFill = true;
            // 
            // g464_GolubtsovDataSet23
            // 
            this.g464_GolubtsovDataSet23.DataSetName = "g464_GolubtsovDataSet23";
            this.g464_GolubtsovDataSet23.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nOMERABindingSource1
            // 
            this.nOMERABindingSource1.DataMember = "NOMER_A";
            this.nOMERABindingSource1.DataSource = this.g464_GolubtsovDataSet23;
            // 
            // nOMER_ATableAdapter1
            // 
            this.nOMER_ATableAdapter1.ClearBeforeFill = true;
            // 
            // g464_GolubtsovDataSet24
            // 
            this.g464_GolubtsovDataSet24.DataSetName = "g464_GolubtsovDataSet24";
            this.g464_GolubtsovDataSet24.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sumBindingSource1
            // 
            this.sumBindingSource1.DataMember = "sum";
            this.sumBindingSource1.DataSource = this.g464_GolubtsovDataSet24;
            // 
            // sumTableAdapter1
            // 
            this.sumTableAdapter1.ClearBeforeFill = true;
            // 
            // g464_GolubtsovDataSet25
            // 
            this.g464_GolubtsovDataSet25.DataSetName = "g464_GolubtsovDataSet25";
            this.g464_GolubtsovDataSet25.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nEOLBHODIMOBindingSource1
            // 
            this.nEOLBHODIMOBindingSource1.DataMember = "NEOLBHODIMO";
            this.nEOLBHODIMOBindingSource1.DataSource = this.g464_GolubtsovDataSet25;
            // 
            // nEOLBHODIMOTableAdapter1
            // 
            this.nEOLBHODIMOTableAdapter1.ClearBeforeFill = true;
            // 
            // Inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 466);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label1);
            this.Name = "Inventory";
            this.Text = "Inventory";
            this.Load += new System.EventHandler(this.Inventory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.charityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nOMERABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nEOLBHODIMOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nOMERABindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nEOLBHODIMOBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private g464_GolubtsovDataSet10 g464_GolubtsovDataSet10;
        private System.Windows.Forms.BindingSource charityBindingSource;
        private g464_GolubtsovDataSet10TableAdapters.CharityTableAdapter charityTableAdapter;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private g464_GolubtsovDataSet11 g464_GolubtsovDataSet11;
        private System.Windows.Forms.BindingSource nOMERABindingSource;
        private g464_GolubtsovDataSet11TableAdapters.NOMER_ATableAdapter nOMER_ATableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn raceKitOptionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expr1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private g464_GolubtsovDataSet12 g464_GolubtsovDataSet12;
        private System.Windows.Forms.BindingSource sumBindingSource;
        private g464_GolubtsovDataSet12TableAdapters.sumTableAdapter sumTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn expr1DataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private g464_GolubtsovDataSet15 g464_GolubtsovDataSet15;
        private System.Windows.Forms.BindingSource nEOLBHODIMOBindingSource;
        private g464_GolubtsovDataSet15TableAdapters.NEOLBHODIMOTableAdapter nEOLBHODIMOTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn neobhodimoDataGridViewTextBoxColumn;
        private g464_GolubtsovDataSet23 g464_GolubtsovDataSet23;
        private System.Windows.Forms.BindingSource nOMERABindingSource1;
        private g464_GolubtsovDataSet23TableAdapters.NOMER_ATableAdapter nOMER_ATableAdapter1;
        private g464_GolubtsovDataSet24 g464_GolubtsovDataSet24;
        private System.Windows.Forms.BindingSource sumBindingSource1;
        private g464_GolubtsovDataSet24TableAdapters.sumTableAdapter sumTableAdapter1;
        private g464_GolubtsovDataSet25 g464_GolubtsovDataSet25;
        private System.Windows.Forms.BindingSource nEOLBHODIMOBindingSource1;
        private g464_GolubtsovDataSet25TableAdapters.NEOLBHODIMOTableAdapter nEOLBHODIMOTableAdapter1;
    }
}