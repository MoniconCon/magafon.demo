﻿namespace MarATHON
{
    partial class Sponsor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.nameRunerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet19 = new MarATHON.g464_GolubtsovDataSet19();
            this.view2BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet2 = new MarATHON.g464_GolubtsovDataSet2();
            this.g464_GolubtsovDataSet = new MarATHON.g464_GolubtsovDataSet();
            this.staffBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.staffTableAdapter = new MarATHON.g464_GolubtsovDataSetTableAdapters.staffTableAdapter();
            this.g464_GolubtsovDataSet1 = new MarATHON.g464_GolubtsovDataSet1();
            this.view2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_2TableAdapter = new MarATHON.g464_GolubtsovDataSet1TableAdapters.View_2TableAdapter();
            this.view_2TableAdapter1 = new MarATHON.g464_GolubtsovDataSet2TableAdapters.View_2TableAdapter();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.god = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.DATA6 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label10 = new System.Windows.Forms.Label();
            this.sum = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.g464_GolubtsovDataSet17 = new MarATHON.g464_GolubtsovDataSet17();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.userTableAdapter = new MarATHON.g464_GolubtsovDataSet17TableAdapters.UserTableAdapter();
            this.g464_GolubtsovDataSet18 = new MarATHON.g464_GolubtsovDataSet18();
            this.nameRunerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nameRunerTableAdapter = new MarATHON.g464_GolubtsovDataSet18TableAdapters.NameRunerTableAdapter();
            this.nameRunerTableAdapter1 = new MarATHON.g464_GolubtsovDataSet19TableAdapters.NameRunerTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.nameRunerBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameRunerBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.nameRunerBindingSource1;
            this.comboBox1.DisplayMember = "Name";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(147, 118);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(270, 21);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.ValueMember = "RegistrationId";
            // 
            // nameRunerBindingSource1
            // 
            this.nameRunerBindingSource1.DataMember = "NameRuner";
            this.nameRunerBindingSource1.DataSource = this.g464_GolubtsovDataSet19;
            // 
            // g464_GolubtsovDataSet19
            // 
            this.g464_GolubtsovDataSet19.DataSetName = "g464_GolubtsovDataSet19";
            this.g464_GolubtsovDataSet19.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view2BindingSource1
            // 
            this.view2BindingSource1.DataMember = "View_2";
            this.view2BindingSource1.DataSource = this.g464_GolubtsovDataSet2;
            // 
            // g464_GolubtsovDataSet2
            // 
            this.g464_GolubtsovDataSet2.DataSetName = "g464_GolubtsovDataSet2";
            this.g464_GolubtsovDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // g464_GolubtsovDataSet
            // 
            this.g464_GolubtsovDataSet.DataSetName = "g464_GolubtsovDataSet";
            this.g464_GolubtsovDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // staffBindingSource
            // 
            this.staffBindingSource.DataMember = "staff";
            this.staffBindingSource.DataSource = this.g464_GolubtsovDataSet;
            // 
            // staffTableAdapter
            // 
            this.staffTableAdapter.ClearBeforeFill = true;
            // 
            // g464_GolubtsovDataSet1
            // 
            this.g464_GolubtsovDataSet1.DataSetName = "g464_GolubtsovDataSet1";
            this.g464_GolubtsovDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view2BindingSource
            // 
            this.view2BindingSource.DataMember = "View_2";
            this.view2BindingSource.DataSource = this.g464_GolubtsovDataSet1;
            // 
            // view_2TableAdapter
            // 
            this.view_2TableAdapter.ClearBeforeFill = true;
            // 
            // view_2TableAdapter1
            // 
            this.view_2TableAdapter1.ClearBeforeFill = true;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.maskedTextBox1.Location = new System.Drawing.Point(147, 221);
            this.maskedTextBox1.Mask = "0000 0000 0000 0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(270, 20);
            this.maskedTextBox1.TabIndex = 2;
            this.maskedTextBox1.Text = "1234123412341234";
            this.maskedTextBox1.Enter += new System.EventHandler(this.maskedTextBox1_Enter);
            this.maskedTextBox1.Leave += new System.EventHandler(this.maskedTextBox1_Leave);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(542, 378);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Оплятить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(563, 289);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(37, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "-";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(649, 289);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 23);
            this.button3.TabIndex = 5;
            this.button3.Text = "+";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(606, 289);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(37, 20);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "50";
            // 
            // textBox2
            // 
            this.textBox2.AccessibleName = "";
            this.textBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox2.Location = new System.Drawing.Point(147, 70);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(270, 20);
            this.textBox2.TabIndex = 7;
            this.textBox2.Tag = "";
            this.textBox2.Text = "Ваше имя";
            this.textBox2.Enter += new System.EventHandler(this.Sponsor_Enter);
            this.textBox2.Leave += new System.EventHandler(this.textBox2_Leave);
            // 
            // textBox3
            // 
            this.textBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox3.Location = new System.Drawing.Point(147, 173);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(270, 20);
            this.textBox3.TabIndex = 8;
            this.textBox3.Text = "Имя владельца";
            this.textBox3.Enter += new System.EventHandler(this.textBox3_Enter);
            this.textBox3.Leave += new System.EventHandler(this.textBox3_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(186, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 42);
            this.label1.TabIndex = 10;
            this.label1.Text = "Спасем китят";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Имя спасителя";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Имя бегуна";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Имя и Фамилия карты";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 227);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Номер карты";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(56, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Дата";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(59, 313);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "CVC";
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.maskedTextBox2.Location = new System.Drawing.Point(147, 313);
            this.maskedTextBox2.Mask = "000";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(33, 20);
            this.maskedTextBox2.TabIndex = 17;
            this.maskedTextBox2.Text = "123";
            this.maskedTextBox2.Enter += new System.EventHandler(this.maskedTextBox2_Enter);
            this.maskedTextBox2.Leave += new System.EventHandler(this.maskedTextBox2_Leave);
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.maskedTextBox3.Location = new System.Drawing.Point(147, 265);
            this.maskedTextBox3.Mask = "00";
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(22, 20);
            this.maskedTextBox3.TabIndex = 18;
            this.maskedTextBox3.Text = "01";
            this.maskedTextBox3.Enter += new System.EventHandler(this.maskedTextBox3_Enter);
            this.maskedTextBox3.Leave += new System.EventHandler(this.maskedTextBox3_Leave);
            // 
            // god
            // 
            this.god.ForeColor = System.Drawing.SystemColors.ControlText;
            this.god.Location = new System.Drawing.Point(204, 265);
            this.god.Mask = "0000";
            this.god.Name = "god";
            this.god.Size = new System.Drawing.Size(31, 20);
            this.god.TabIndex = 19;
            this.god.Text = "2019";
            this.god.Enter += new System.EventHandler(this.god_Enter);
            this.god.Leave += new System.EventHandler(this.god_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(472, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(212, 24);
            this.label8.TabIndex = 20;
            this.label8.Text = "Благотворительность";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(521, 118);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 16);
            this.label9.TabIndex = 21;
            this.label9.Text = "Спасем китят";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(623, 108);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(41, 37);
            this.button4.TabIndex = 22;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // DATA6
            // 
            this.DATA6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.DATA6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DATA6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.DATA6.Location = new System.Drawing.Point(53, 455);
            this.DATA6.Name = "DATA6";
            this.DATA6.Size = new System.Drawing.Size(617, 40);
            this.DATA6.TabIndex = 23;
            this.DATA6.Text = " ";
            this.DATA6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.DATA6.UseCompatibleTextRendering = true;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(537, 209);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(161, 25);
            this.label10.TabIndex = 24;
            this.label10.Text = "Сумма жертвы";
            // 
            // sum
            // 
            this.sum.AutoSize = true;
            this.sum.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sum.Location = new System.Drawing.Point(587, 234);
            this.sum.Name = "sum";
            this.sum.Size = new System.Drawing.Size(83, 39);
            this.sum.TabIndex = 25;
            this.sum.Text = "50 $";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(623, 378);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 26;
            this.button5.Text = "Отсена";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(20, 9);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 27;
            this.button6.Text = "Назалд";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // g464_GolubtsovDataSet17
            // 
            this.g464_GolubtsovDataSet17.DataSetName = "g464_GolubtsovDataSet17";
            this.g464_GolubtsovDataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataMember = "User";
            this.userBindingSource.DataSource = this.g464_GolubtsovDataSet17;
            // 
            // userTableAdapter
            // 
            this.userTableAdapter.ClearBeforeFill = true;
            // 
            // g464_GolubtsovDataSet18
            // 
            this.g464_GolubtsovDataSet18.DataSetName = "g464_GolubtsovDataSet18";
            this.g464_GolubtsovDataSet18.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nameRunerBindingSource
            // 
            this.nameRunerBindingSource.DataMember = "NameRuner";
            this.nameRunerBindingSource.DataSource = this.g464_GolubtsovDataSet18;
            // 
            // nameRunerTableAdapter
            // 
            this.nameRunerTableAdapter.ClearBeforeFill = true;
            // 
            // nameRunerTableAdapter1
            // 
            this.nameRunerTableAdapter1.ClearBeforeFill = true;
            // 
            // Sponsor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 521);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.sum);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.DATA6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.god);
            this.Controls.Add(this.maskedTextBox3);
            this.Controls.Add(this.maskedTextBox2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.comboBox1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Sponsor";
            this.Text = "Marathfons skill 2019 - sponsor a runne4r";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.Enter += new System.EventHandler(this.Sponsor_Enter);
            ((System.ComponentModel.ISupportInitialize)(this.nameRunerBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nameRunerBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private g464_GolubtsovDataSet g464_GolubtsovDataSet;
        private System.Windows.Forms.BindingSource staffBindingSource;
        private g464_GolubtsovDataSetTableAdapters.staffTableAdapter staffTableAdapter;
        private g464_GolubtsovDataSet1 g464_GolubtsovDataSet1;
        private System.Windows.Forms.BindingSource view2BindingSource;
        private g464_GolubtsovDataSet1TableAdapters.View_2TableAdapter view_2TableAdapter;
        private g464_GolubtsovDataSet2 g464_GolubtsovDataSet2;
        private System.Windows.Forms.BindingSource view2BindingSource1;
        private g464_GolubtsovDataSet2TableAdapters.View_2TableAdapter view_2TableAdapter1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.MaskedTextBox god;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label DATA6;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label sum;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox1;
        private g464_GolubtsovDataSet17 g464_GolubtsovDataSet17;
        private System.Windows.Forms.BindingSource userBindingSource;
        private g464_GolubtsovDataSet17TableAdapters.UserTableAdapter userTableAdapter;
        private g464_GolubtsovDataSet18 g464_GolubtsovDataSet18;
        private System.Windows.Forms.BindingSource nameRunerBindingSource;
        private g464_GolubtsovDataSet18TableAdapters.NameRunerTableAdapter nameRunerTableAdapter;
        private g464_GolubtsovDataSet19 g464_GolubtsovDataSet19;
        private System.Windows.Forms.BindingSource nameRunerBindingSource1;
        private g464_GolubtsovDataSet19TableAdapters.NameRunerTableAdapter nameRunerTableAdapter1;
    }
}