﻿namespace MarATHON
{
    partial class newrunerr3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.charityBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet21 = new MarATHON.g464_GolubtsovDataSet21();
            this.charityBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet9 = new MarATHON.g464_GolubtsovDataSet9();
            this.sponsorshipBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g464_GolubtsovDataSet7 = new MarATHON.g464_GolubtsovDataSet7();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.sponsorshipTableAdapter = new MarATHON.g464_GolubtsovDataSet7TableAdapters.SponsorshipTableAdapter();
            this.g464_GolubtsovDataSet8 = new MarATHON.g464_GolubtsovDataSet8();
            this.charityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.charityTableAdapter = new MarATHON.g464_GolubtsovDataSet8TableAdapters.CharityTableAdapter();
            this.charityTableAdapter1 = new MarATHON.g464_GolubtsovDataSet9TableAdapters.CharityTableAdapter();
            this.charityTableAdapter2 = new MarATHON.g464_GolubtsovDataSet21TableAdapters.CharityTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.charityBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.charityBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sponsorshipBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.charityBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(263, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Регистрация на марафон";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(79, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(471, 44);
            this.label2.TabIndex = 1;
            this.label2.Text = "Пожалуйста заполните всю информация для регистрации на marafon skills 2019 провод" +
    "имый в Москве. Rusian. C Вами свяжутся после регистрации";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Вид марафона";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(362, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Вариант комлектов";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(49, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Детали спонсорства";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(362, 305);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Регистрационный взнос";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(61, 141);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(180, 17);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "42 км Полный марафон ($145)";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(61, 174);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(156, 17);
            this.checkBox2.TabIndex = 7;
            this.checkBox2.Text = "21 км Полумарафон ($75)";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.CheckBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(61, 210);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(162, 17);
            this.checkBox3.TabIndex = 8;
            this.checkBox3.Text = "5 км Малая дистанция ($5)";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.CheckBox3_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(365, 141);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(256, 17);
            this.radioButton1.TabIndex = 9;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Вариант А ($0): Номер бегуна + RFID браслет";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(365, 174);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(311, 17);
            this.radioButton2.TabIndex = 10;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Вариант B ($20): Вариант А + бейсболка + бутылка воды";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(365, 209);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(332, 17);
            this.radioButton3.TabIndex = 11;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Вариант C ($45): Вариант В + футболка + сувенирный буклет";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.RadioButton3_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(53, 330);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Взнос";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 356);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Сумма взноса";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(41, 428);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Регистрация";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(149, 428);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "Отмена";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.charityBindingSource2;
            this.comboBox2.DisplayMember = "CharityName";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(102, 327);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 17;
            this.comboBox2.ValueMember = "CharityId";
            // 
            // charityBindingSource2
            // 
            this.charityBindingSource2.DataMember = "Charity";
            this.charityBindingSource2.DataSource = this.g464_GolubtsovDataSet21;
            // 
            // g464_GolubtsovDataSet21
            // 
            this.g464_GolubtsovDataSet21.DataSetName = "g464_GolubtsovDataSet21";
            this.g464_GolubtsovDataSet21.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // charityBindingSource1
            // 
            this.charityBindingSource1.DataMember = "Charity";
            this.charityBindingSource1.DataSource = this.g464_GolubtsovDataSet9;
            // 
            // g464_GolubtsovDataSet9
            // 
            this.g464_GolubtsovDataSet9.DataSetName = "g464_GolubtsovDataSet9";
            this.g464_GolubtsovDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sponsorshipBindingSource
            // 
            this.sponsorshipBindingSource.DataMember = "Sponsorship";
            this.sponsorshipBindingSource.DataSource = this.g464_GolubtsovDataSet7;
            // 
            // g464_GolubtsovDataSet7
            // 
            this.g464_GolubtsovDataSet7.DataSetName = "g464_GolubtsovDataSet7";
            this.g464_GolubtsovDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(410, 356);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "0";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(103, 356);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = "0";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 8);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 21;
            this.button3.Text = "Назад";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(606, 8);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 22;
            this.button4.Text = "Выйти";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(229, 327);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(21, 23);
            this.button5.TabIndex = 23;
            this.button5.Text = "I";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // sponsorshipTableAdapter
            // 
            this.sponsorshipTableAdapter.ClearBeforeFill = true;
            // 
            // g464_GolubtsovDataSet8
            // 
            this.g464_GolubtsovDataSet8.DataSetName = "g464_GolubtsovDataSet8";
            this.g464_GolubtsovDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // charityBindingSource
            // 
            this.charityBindingSource.DataMember = "Charity";
            this.charityBindingSource.DataSource = this.g464_GolubtsovDataSet8;
            // 
            // charityTableAdapter
            // 
            this.charityTableAdapter.ClearBeforeFill = true;
            // 
            // charityTableAdapter1
            // 
            this.charityTableAdapter1.ClearBeforeFill = true;
            // 
            // charityTableAdapter2
            // 
            this.charityTableAdapter2.ClearBeforeFill = true;
            // 
            // newrunerr3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 492);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "newrunerr3";
            this.Text = "newrunerr3";
            this.Load += new System.EventHandler(this.Newrunerr3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.charityBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.charityBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sponsorshipBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_GolubtsovDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.charityBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private g464_GolubtsovDataSet7 g464_GolubtsovDataSet7;
        private System.Windows.Forms.BindingSource sponsorshipBindingSource;
        private g464_GolubtsovDataSet7TableAdapters.SponsorshipTableAdapter sponsorshipTableAdapter;
        private g464_GolubtsovDataSet8 g464_GolubtsovDataSet8;
        private System.Windows.Forms.BindingSource charityBindingSource;
        private g464_GolubtsovDataSet8TableAdapters.CharityTableAdapter charityTableAdapter;
        private g464_GolubtsovDataSet9 g464_GolubtsovDataSet9;
        private System.Windows.Forms.BindingSource charityBindingSource1;
        private g464_GolubtsovDataSet9TableAdapters.CharityTableAdapter charityTableAdapter1;
        private g464_GolubtsovDataSet21 g464_GolubtsovDataSet21;
        private System.Windows.Forms.BindingSource charityBindingSource2;
        private g464_GolubtsovDataSet21TableAdapters.CharityTableAdapter charityTableAdapter2;
    }
}